exports.handler = async function(event, context) {
  const EVENT_ID = "401811937"; // Players Championship 2026
  const url = `https://site.api.espn.com/apis/site/v2/sports/golf/pga/leaderboard?event=${EVENT_ID}`;

  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`ESPN returned ${res.status}`);
    const data = await res.json();

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "public, max-age=60",
      },
      body: JSON.stringify(data),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message }),
    };
  }
};
